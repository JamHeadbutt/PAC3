player_manager.AddValidModel("Gorge MacRoyal", "models/survivors/cowboy_pm.mdl")
player_manager.AddValidHands("Gorge MacRoyal", "models/weapons/c_arms_citizen.mdl", 0, "00000000")